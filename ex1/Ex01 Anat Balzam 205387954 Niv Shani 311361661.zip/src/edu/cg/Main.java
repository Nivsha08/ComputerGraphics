package edu.cg;
import edu.cg.menu.MenuWindow;

public class Main {
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		MenuWindow mw = new MenuWindow();
		mw.setVisible(true);
	}
}
