*************************
Computer Graphics - Ex.5

Anat Balzam - 205387954
Niv Shani - 311361661
*************************

New design features:
*************************

1. Center strip - added on the front hoods and back of the car (double strip).
2. EngineBox - the car engine tray/box/hood, added on the back of the car.
3. Exhaust - double exhaust added in the bottom back of the car.
4. Back lights - added a F1-style break lights, in the back of the car.
5. General colors modifications.
