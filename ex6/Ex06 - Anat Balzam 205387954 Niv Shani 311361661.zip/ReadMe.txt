*************************
Computer Graphics - Ex.6

Anat Balzam - 205387954
Niv Shani - 311361661
*************************

- All basic (mandatory) implementation is done and working.
- We didn't implement the bonus part.
- We use MacOSX and had a really hard time exporting the JAR file in reasonable size (including after trying doing this via Eclipse).
We've added screenshots of our implementation as suggested on Piazza.